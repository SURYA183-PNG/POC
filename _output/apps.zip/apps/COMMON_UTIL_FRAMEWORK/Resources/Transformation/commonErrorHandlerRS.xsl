<?xml version='1.0' encoding='UTF-8'?>
<xsl:stylesheet version="1.0" exclude-result-prefixes="xsd oracle-xsl-mapper xsi xsl tns UUIDUserFunction IsUserInGroupFunction oraext IsUserInRoleFunction xp20 DVMFunctions oraxsl RuntimeTypeConversionFunctions XrefFunctions BasicCredentialsUserFunction" xmlns:UUIDUserFunction="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.stages.functions.UUIDUserFunction" xmlns:IsUserInGroupFunction="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.stages.functions.IsUserInGroupFunction" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:IsUserInRoleFunction="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.stages.functions.IsUserInRoleFunction" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:DVMFunctions="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.functions.dvm.DVMFunctions" xmlns:tns="http://TargetNamespace.com/commonJDEFault" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:oraxsl="http://www.oracle.com/XSL/Transform/java" xmlns:RuntimeTypeConversionFunctions="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.stages.functions.RuntimeTypeConversionFunctions" xmlns:XrefFunctions="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.functions.xref.XrefFunctions" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:BasicCredentialsUserFunction="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.stages.functions.BasicCredentialsUserFunction" xmlns:nxsd="http://xmlns.oracle.com/pcbpel/nxsd">
<oracle-xsl-mapper:schema>
<oracle-xsl-mapper:mapSources>
<oracle-xsl-mapper:source/>
</oracle-xsl-mapper:mapSources>
<oracle-xsl-mapper:mapTargets>
<oracle-xsl-mapper:target type="XSD">
<oracle-xsl-mapper:schema location="../XSD/commonFaultResponse.xsd"/>
<oracle-xsl-mapper:rootElement name="Root-Element" namespace="http://TargetNamespace.com/commonJDEFault"/>
</oracle-xsl-mapper:target>
</oracle-xsl-mapper:mapTargets>
</oracle-xsl-mapper:schema>
<xsl:param name="fault"/>
<xsl:template match="/">
<tns:Root-Element>
<tns:Fault>
<xsl:choose>
<xsl:when test="$fault//*:faultcode">
<tns:faultcode>
<xsl:value-of select="$fault//*:faultcode"/>
</tns:faultcode>
</xsl:when>
<xsl:otherwise>
<tns:faultcode>
<xsl:value-of select="$fault//*:errorCode"/>
</tns:faultcode>
</xsl:otherwise>
</xsl:choose>
<xsl:choose>
<xsl:when test="$fault//*:faultstring">
<tns:faultstring>
<xsl:value-of select="$fault//*:faultstring"/>
</tns:faultstring>
</xsl:when>
<xsl:otherwise>
<tns:faultstring>
<xsl:value-of select="$fault//*:reason"/>
</tns:faultstring>
</xsl:otherwise>
</xsl:choose>
<tns:detail>
<tns:BusinessServiceException>
<tns:faultInfo>
<xsl:value-of select="$fault//*:faultInfo"/>
</tns:faultInfo>
<tns:message>
<xsl:value-of select="$fault//*:message"/>
</tns:message>
<tns:requestID>
<xsl:value-of select="$fault//*:requestID"/>
</tns:requestID>
</tns:BusinessServiceException>
</tns:detail>
</tns:Fault>
</tns:Root-Element>
</xsl:template>
</xsl:stylesheet>
